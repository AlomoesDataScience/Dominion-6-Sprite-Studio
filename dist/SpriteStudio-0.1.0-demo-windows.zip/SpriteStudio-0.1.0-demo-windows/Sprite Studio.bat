@echo off
rem Starts Sprite Studio with the Python bundled in this folder (nothing to install).
start "" "%~dp0python\pythonw.exe" -X utf8 "%~dp0app\start.py" %*
